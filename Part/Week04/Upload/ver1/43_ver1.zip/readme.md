# Dungeon Project

## Week 5

### Run

```
./submit/main.exe
```

### CMakeLists.txt

```cmake
project(Week04_Framework)

set(Week04_SRC_LIST 
    ${PROJECT_SOURCE_DIR}/Week04/main.cpp
)

add_executable(Week04 ${Week04_SRC_LIST})
```

