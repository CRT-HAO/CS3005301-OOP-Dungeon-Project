/**
 * @ Author: 張皓鈞 (B11030202@mail.ntust.edu.tw)
 * @ Create Time: 2023-02-21 19:52:33
 * @ Modified by: 鄭健廷 (B11130225@mail.ntust.edu.tw)
 * @ Modified time: 2023-02-26 20:35:38
 * @ Description: Output W,A,S,D after input, ESC to stop process.
 */

#include <conio.h> // For getch() function

#include <iostream> // For print out information

using namespace std;

// Define inputs and its index
enum ValidInput
{
    EW = 0,
    ES = 1,
    EA = 2,
    ED = 3,
    ESPACE = 4,
    EESC = 5,
    INVALID,
};

bool keep = true;
bool state[6]{0};

// Detect state of input
void keyUpdate(bool key[]);

int main()
{
    // Initialize state of key
    bool gKeyState[ValidInput::INVALID];

    // Obtain and update the input using a loop
    /************************************************************************/
    /*Please implement your code here*/
    while ( keep )
    {
        keyUpdate(state);
    }
    /************************************************************************/
}

//******************************************************************
//
// * 偵測輸入狀態
//==================================================================
void keyUpdate(bool key[])
//==================================================================
{
    for ( int i = 0; i < ValidInput::INVALID; i++ )
    {
        key[i] = false;
    }
    char input = _getch();

    // Implement a switch for output calls
    /************************************************************************/
    /*Please implement your code here*/
    switch ( input )
    {
    case 'w':
        cout << "Key W is pressed\n";
        break;

    case 's':
        cout << "Key S is pressed\n";
        break;

    case 'a':
        cout << "Key A is pressed\n";
        break;

    case 'd':
        cout << "Key D is pressed\n";
        break;

    default:
        keep = false;
        cout << "Key ESC is pressed. End program\n";
        break;
        break;
    }
    /************************************************************************/
}
