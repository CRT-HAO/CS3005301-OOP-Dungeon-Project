/**
 * @ Author: 張皓鈞 (B11030202@mail.ntust.edu.tw)
 * @ Create Time: 2023-02-21 19:52:33
 * @ Modified by: 鄭健廷 (B11130225@mail.ntust.edu.tw)
 * @ Modified time: 2023-02-26 20:34:54
 * @ Description: Use clock to count time (And output) for following input tasks
 */

#include <ctime>
#include <iomanip>
#include <iostream>
#include <math.h>

using namespace std;

int main(int argc, char **argv)
{
    clock_t startT, endT;
    int duration = 0, a = 0;
    double timer = 0;

    for ( int i = 0; i < 15; i++ )
    {
        startT = clock();
        timer = startT / 1000;
        clock_t globalStartT = startT;
        endT = 1000 + startT;
        cout << "Total time " << i << " at " << fixed << setprecision(3) << timer << endl;
        while ( endT >= timer )
        {
            timer = clock();
        }
    }
    return 0;
}